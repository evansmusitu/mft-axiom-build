var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};

// ../../axiom_interface/vnext/execution_integrity.mjs
function canonicalJson(value) {
  const ancestors = /* @__PURE__ */ new Set();
  function encode(v) {
    if (v === null || typeof v === "string" || typeof v === "boolean") return JSON.stringify(v);
    if (typeof v === "number") {
      if (!Number.isFinite(v)) throw new TypeError("finite JSON numbers required");
      return JSON.stringify(v);
    }
    if (typeof v !== "object") throw new TypeError("JSON values required");
    if (ancestors.has(v)) throw new TypeError("cyclic JSON is not supported");
    if (!Array.isArray(v) && ![Object.prototype, null].includes(Object.getPrototypeOf(v))) throw new TypeError("plain JSON records required");
    if (Object.getOwnPropertySymbols(v).length) throw new TypeError("symbol keys are not JSON");
    ancestors.add(v);
    let encoded;
    if (Array.isArray(v)) {
      if (Object.keys(v).length !== v.length) throw new TypeError("dense JSON arrays required");
      encoded = "[" + v.map(encode).join(",") + "]";
    } else {
      encoded = "{" + Object.keys(v).sort().map((k) => {
        const d = Object.getOwnPropertyDescriptor(v, k);
        if (!d || !("value" in d)) throw new TypeError("JSON accessors are not supported");
        return JSON.stringify(k) + ":" + encode(d.value);
      }).join(",") + "}";
    }
    ancestors.delete(v);
    return encoded;
  }
  __name(encode, "encode");
  return encode(value);
}
async function sha256Json(value) {
  const bytes = new TextEncoder().encode(canonicalJson(value));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
var init_execution_integrity = __esm({
  "../../axiom_interface/vnext/execution_integrity.mjs"() {
    __name(canonicalJson, "canonicalJson");
    __name(sha256Json, "sha256Json");
  }
});

// ../independent-ledger/protocol.mjs
init_execution_integrity();
var encoder = new TextEncoder();
var LedgerDenied = class extends Error {
  static {
    __name(this, "LedgerDenied");
  }
  constructor(code, status = 403) {
    super(code);
    this.name = "LedgerDenied";
    this.code = code;
    this.status = status;
  }
};
var deny = /* @__PURE__ */ __name((code, status = 403) => {
  throw new LedgerDenied(code, status);
}, "deny");
function exact(value, keys, label) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((k) => !keys.includes(k)) || keys.some((k) => !Object.hasOwn(value, k))) deny("INVALID_" + label, 400);
  return value;
}
__name(exact, "exact");
var integer = /* @__PURE__ */ __name((v, max = 1e6) => {
  if (!Number.isSafeInteger(v) || v < 0 || v > max) deny("INVALID_COUNTER", 400);
  return v;
}, "integer");
function fromB64(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value) || value.length > 200) deny("INVALID_SIGNATURE", 400);
  return Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/")), (c) => c.charCodeAt(0));
}
__name(fromB64, "fromB64");
function publicKey(jwk) {
  exact(jwk, ["kty", "crv", "x"], "PUBLIC_KEY");
  if (jwk.kty !== "OKP" || jwk.crv !== "Ed25519" || fromB64(jwk.x).length !== 32) deny("INVALID_PUBLIC_KEY", 400);
  return jwk;
}
__name(publicKey, "publicKey");

// ../independent-ledger/github-anchor.mjs
var SCHEMA = "musitu.axiom.github-checkpoint.v1";
function anchorCredential(token, code = "ANCHOR_CREDENTIAL_REQUIRED", status = 503) {
  if (typeof token !== "string" || token.length < 20 || token.length > 8192 || !/^[A-Za-z0-9._~+\/-]+={0,2}$/.test(token)) deny(code, status);
  return token;
}
__name(anchorCredential, "anchorCredential");
function anchorPin(value) {
  exact(value, ["repository", "repository_id", "namespace", "target_commitish"], "ANCHOR_PIN");
  if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(value.repository) || value.repository.includes("..") || !Number.isSafeInteger(value.repository_id) || value.repository_id < 1 || !/^ax-[a-z0-9-]{1,60}$/.test(value.namespace) || !/^[0-9a-f]{40}$/.test(value.target_commitish)) deny("INVALID_ANCHOR_PIN", 400);
  return Object.freeze(structuredClone(value));
}
__name(anchorPin, "anchorPin");
function checkpointTag(pin, payload) {
  integer(payload.ledger_sequence ?? payload.sequence);
  return pin.namespace + "-" + String(payload.ledger_sequence ?? payload.sequence).padStart(12, "0");
}
__name(checkpointTag, "checkpointTag");
function content(pin, payload) {
  const { anchor, highwater, ...unanchored } = payload;
  return canonicalJson({ schema: SCHEMA, pin, payload: unanchored });
}
__name(content, "content");
async function contentDigest(pin, payload) {
  return "sha256:" + await sha256Json(JSON.parse(content(pin, payload)));
}
__name(contentDigest, "contentDigest");
function transport(pin, token, fetchImpl) {
  anchorCredential(token);
  const root = "/repos/" + pin.repository;
  return async (method, path, body, upload = false) => {
    if (!path.startsWith(root + "/") && path !== root) deny("ANCHOR_REPOSITORY_SCOPE_DENIED");
    let timer;
    const controller = new AbortController();
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => {
        controller.abort();
        reject(Error("deadline"));
      }, 1e4);
    });
    try {
      const response = await Promise.race([fetchImpl((upload ? "https://uploads.github.com" : "https://api.github.com") + path, { method, redirect: "manual", credentials: "omit", cache: "no-store", signal: controller.signal, headers: { authorization: "Bearer " + token, accept: "application/vnd.github+json", "user-agent": "musitu-axiom-checkpoint", "x-github-api-version": "2022-11-28", ...body === void 0 ? {} : { "content-type": "application/json" } }, ...body === void 0 ? {} : { body: upload ? body : JSON.stringify(body) } }), deadline]);
      const reader = response.body?.getReader(), decoder = new TextDecoder();
      let text = "", size = 0;
      if (reader) {
        try {
          for (; ; ) {
            const next = await Promise.race([reader.read(), deadline]);
            if (next.done) break;
            size += next.value.byteLength;
            if (size > 131072) deny("ANCHOR_REPLY_TOO_LARGE_HOLD", 503);
            text += decoder.decode(next.value, { stream: true });
          }
          text += decoder.decode();
        } finally {
          void reader.cancel().catch(() => {
          });
          reader.releaseLock();
        }
      }
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        deny("ANCHOR_REPLY_INVALID_HOLD", 503);
      }
      return { status: response.status, data };
    } catch (error) {
      if (error?.code) throw error;
      deny("ANCHOR_TRANSPORT_AMBIGUOUS_HOLD", 503);
    } finally {
      clearTimeout(timer);
    }
  };
}
__name(transport, "transport");
function successful(reply2, status) {
  if (reply2.status !== status) deny("ANCHOR_WRITE_UNCONFIRMED_HOLD", 503);
  return reply2.data;
}
__name(successful, "successful");
async function identity(api, pin) {
  const repo = successful(await api("GET", "/repos/" + pin.repository), 200);
  if (repo.id !== pin.repository_id || repo.full_name !== pin.repository || repo.archived === true) deny("ANCHOR_REPOSITORY_IDENTITY_CHANGED_HOLD", 503);
  if (repo.private !== true) deny("ANCHOR_REPOSITORY_PRIVACY_HOLD", 503);
}
__name(identity, "identity");
async function verify(api, pin, payload, proof) {
  exact(proof, ["schema", "repository_id", "namespace", "tag", "release_id", "asset_digest"], "ANCHOR_PROOF");
  const tag = checkpointTag(pin, payload), digest = await contentDigest(pin, payload);
  if (proof.schema !== SCHEMA || proof.repository_id !== pin.repository_id || proof.namespace !== pin.namespace || proof.tag !== tag || proof.asset_digest !== digest || !Number.isSafeInteger(proof.release_id) || proof.release_id < 1) deny("ANCHOR_BINDING_MISMATCH_HOLD", 503);
  const root = "/repos/" + pin.repository, r = successful(await api("GET", root + "/releases/" + proof.release_id), 200);
  const size = new TextEncoder().encode(content(pin, payload)).length;
  if (r.id !== proof.release_id || r.immutable !== true || r.draft !== false || r.tag_name !== tag || r.assets?.length !== 1 || r.assets[0].name !== "checkpoint.json" || r.assets[0].state !== "uploaded" || r.assets[0].size !== size || r.assets[0].digest !== digest) deny("ANCHOR_IMMUTABLE_PROOF_MISSING_HOLD", 503);
  const ref = successful(await api("GET", root + "/git/ref/tags/" + tag), 200);
  if (ref.ref !== "refs/tags/" + tag || ref.object?.type !== "commit" || ref.object.sha !== pin.target_commitish) deny("ANCHOR_TARGET_CHANGED_HOLD", 503);
  return true;
}
__name(verify, "verify");
async function verifyGithubCheckpoint({ pin, token, payload, fetchImpl = fetch }) {
  pin = anchorPin(pin);
  const api = transport(pin, token, fetchImpl);
  await identity(api, pin);
  await verify(api, pin, payload, payload.anchor);
  await identity(api, pin);
  return true;
}
__name(verifyGithubCheckpoint, "verifyGithubCheckpoint");

// authority2-r2-worm.mjs
var ID = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,179}$/;
var WormHold = class extends Error {
  static {
    __name(this, "WormHold");
  }
  constructor(reason) {
    super(reason);
    this.name = "WormHold";
    this.reason = reason;
  }
};
var hold = /* @__PURE__ */ __name((code) => {
  throw new WormHold(code);
}, "hold");
function wormKey(pin, seq) {
  if (!pin || pin.account_id !== "67469478aa9349fa0a57fe3a72da200a" || !ID.test(pin.ledger_id) || !/^ax-[a-z0-9-]{1,60}$/.test(pin.namespace) || !Number.isSafeInteger(seq) || seq < 0 || seq > 1000001) hold("HIGHWATER_WORM_ID_INVALID_HOLD");
  return `b27/${pin.account_id}/${pin.ledger_id}/${pin.namespace}/${String(seq).padStart(12, "0")}.json`;
}
__name(wormKey, "wormKey");

// authority2-genesis-candidate.mjs
var ACCOUNT = "67469478aa9349fa0a57fe3a72da200a";
var BUNDLE = "d1ddd1e944bfa4560cc662f7fd12a9b22b3f6493175e4a38b2b3db7e1aed4210";
var SCHEMA2 = "musitu.axiom.authority2.pre-genesis-commitment.v1";
var H64 = /^[a-f0-9]{64}$/;
var ID2 = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,179}$/;
var PIN_KEYS = ["account_id", "ledger_id", "namespace", "key_id", "public_key_jwk"];
var COMMITMENT_KEYS = [
  "schema",
  "ledger_sequence",
  "kind",
  ...PIN_KEYS,
  "reviewed_bundle_sha256",
  "genesis_nonce",
  "initial_sequence",
  "initial_head"
];
var encoder2 = new TextEncoder();
var GenesisHold = class extends Error {
  static {
    __name(this, "GenesisHold");
  }
  constructor(code) {
    super(code);
    this.name = "GenesisHold";
    this.code = code;
  }
};
var hold2 = /* @__PURE__ */ __name((code) => {
  throw new GenesisHold(code);
}, "hold");
function validatedPin(value) {
  exact(value, PIN_KEYS, "GENESIS_PIN");
  publicKey(value.public_key_jwk);
  if (value.account_id !== ACCOUNT || typeof value.ledger_id !== "string" || typeof value.key_id !== "string" || typeof value.namespace !== "string" || !ID2.test(value.ledger_id) || !ID2.test(value.key_id) || !/^ax-[a-z0-9-]{1,60}$/.test(value.namespace)) hold2("A2_GENESIS_IDENTITY_HOLD");
  wormKey(value, 0);
  return value;
}
__name(validatedPin, "validatedPin");
function requireStorage(storage) {
  if (!storage || typeof storage.sql?.exec !== "function" || ["get", "put", "delete", "list", "getAlarm", "transaction", "sync"].some(
    (name) => typeof storage[name] !== "function"
  )) hold2("A2_GENESIS_STORAGE_BINDING_HOLD");
}
__name(requireStorage, "requireStorage");
function requireBucket(bucket) {
  if (!bucket || ["get", "head", "put", "list"].some(
    (name) => typeof bucket[name] !== "function"
  )) hold2("A2_GENESIS_R2_BINDING_HOLD");
}
__name(requireBucket, "requireBucket");
async function boundedR2(operation) {
  let timer;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(
      () => reject(new GenesisHold("A2_GENESIS_R2_AMBIGUOUS_HOLD")),
      3e3
    );
  });
  try {
    return await Promise.race([operation(), deadline]);
  } finally {
    clearTimeout(timer);
  }
}
__name(boundedR2, "boundedR2");
async function emptyStorage(storage, alarmStorage) {
  const values = await storage.list({ limit: 1 });
  if (!(values instanceof Map) || values.size !== 0 || await alarmStorage.getAlarm() !== null)
    hold2("A2_GENESIS_EXISTING_DO_STATE_HOLD");
}
__name(emptyStorage, "emptyStorage");
function prefixFor(pin) {
  return wormKey(pin, 0).replace(/000000000000\.json$/, "");
}
__name(prefixFor, "prefixFor");
function genesisBarrierKey(pin) {
  return prefixFor(validatedPin(pin)) + "genesis.json";
}
__name(genesisBarrierKey, "genesisBarrierKey");
async function provisionAuthority2Genesis({
  storage,
  bucket,
  pin,
  anchor_pin,
  commitment,
  anchor_proof,
  expected_commitment_sha256,
  anchor_read_token,
  fetchImpl = fetch,
  deadline_ms = Number.MAX_SAFE_INTEGER
}) {
  requireStorage(storage);
  requireBucket(bucket);
  if (!Number.isSafeInteger(deadline_ms) || deadline_ms < 1)
    hold2("A2_GENESIS_DEADLINE_INVALID_HOLD");
  const checkDeadline = /* @__PURE__ */ __name(() => {
    if (Date.now() >= deadline_ms) hold2("A2_GENESIS_DEADLINE_EXPIRED_HOLD");
  }, "checkDeadline");
  checkDeadline();
  const c = validatedPin(structuredClone(pin));
  const a = anchorPin(structuredClone(anchor_pin));
  const p = structuredClone(commitment), proof = structuredClone(anchor_proof);
  exact(p, COMMITMENT_KEYS, "GENESIS_COMMITMENT");
  if (typeof expected_commitment_sha256 !== "string" || !H64.test(expected_commitment_sha256) || await sha256Json(p) !== expected_commitment_sha256)
    hold2("A2_GENESIS_APPROVED_HASH_MISMATCH_HOLD");
  if (p.schema !== SCHEMA2 || p.ledger_sequence !== 0 || p.kind !== "AUTHORITY2_PREGENESIS" || p.initial_sequence !== -1 || p.initial_head !== "0".repeat(64) || p.reviewed_bundle_sha256 !== BUNDLE || typeof p.genesis_nonce !== "string" || !H64.test(p.genesis_nonce) || a.namespace === c.namespace || PIN_KEYS.some((k) => canonicalJson(p[k]) !== canonicalJson(c[k])))
    hold2("A2_GENESIS_COMMITMENT_BINDING_HOLD");
  const anchored = { ...p, anchor: proof };
  await verifyGithubCheckpoint({
    pin: a,
    token: anchor_read_token,
    payload: anchored,
    fetchImpl
  });
  const barrierKey = genesisBarrierKey(c), prefix = prefixFor(c);
  const barrier = canonicalJson({
    schema: "musitu.axiom.authority2.genesis-barrier.v1",
    commitment: p,
    commitment_sha256: expected_commitment_sha256,
    anchor_pin: a,
    anchor: proof
  });
  if (encoder2.encode(barrier).length > 8192) hold2("A2_GENESIS_BARRIER_SIZE_HOLD");
  const pending = {
    kind: "AUTHORITY2_GENESIS_PENDING",
    commitment_sha256: expected_commitment_sha256,
    barrier_key: barrierKey,
    deadline_ms
  };
  await storage.transaction(async (s) => {
    checkDeadline();
    await emptyStorage(s, storage);
    await s.put("highwater/pending", pending);
  });
  await storage.sync();
  await boundedR2(async () => {
    checkDeadline();
    const before = await bucket.list({ prefix, limit: 1 });
    if (!before || !Array.isArray(before.objects) || before.objects.length || before.truncated !== false)
      hold2("A2_GENESIS_EXISTING_R2_HISTORY_HOLD");
    checkDeadline();
    const result = await bucket.put(barrierKey, barrier, {
      onlyIf: new Headers({ "if-none-match": "*" }),
      httpMetadata: { contentType: "application/json" }
    });
    if (!result) hold2("A2_GENESIS_R2_BARRIER_UNCONFIRMED_HOLD");
    const read = await bucket.get(barrierKey);
    if (!read || read.size !== encoder2.encode(barrier).length || await read.text() !== barrier)
      hold2("A2_GENESIS_R2_BARRIER_READBACK_HOLD");
    const after = await bucket.list({ prefix, limit: 2 });
    if (!after || !Array.isArray(after.objects) || after.truncated !== false || after.objects.length !== 1 || after.objects[0].key !== barrierKey || await bucket.head(wormKey(c, 0))) hold2("A2_GENESIS_R2_NAMESPACE_CHANGED_HOLD");
  });
  checkDeadline();
  await verifyGithubCheckpoint({
    pin: a,
    token: anchor_read_token,
    payload: anchored,
    fetchImpl
  });
  const { public_key_jwk: _publicKey, ...identity2 } = c;
  await storage.transaction(async (s) => {
    checkDeadline();
    const values = await s.list({ limit: 2 });
    if (!(values instanceof Map) || values.size !== 1 || canonicalJson(values.get("highwater/pending") ?? null) !== canonicalJson(pending) || await storage.getAlarm() !== null) hold2("A2_GENESIS_PENDING_CHANGED_HOLD");
    await s.put("highwater/genesis", {
      commitment_sha256: expected_commitment_sha256,
      barrier_key: barrierKey,
      anchor_pin: a,
      anchor: proof
    });
    await s.put("highwater/tip", { ...identity2, sequence: -1, head: "0".repeat(64) });
    await s.delete("highwater/pending");
  });
  await storage.sync();
  return {
    schema: "musitu.axiom.authority2.genesis-candidate-result.v1",
    status: "PREGENESIS_COMMITTED_CANDIDATE_ONLY",
    commitment_sha256: expected_commitment_sha256,
    barrier_key: barrierKey,
    initial_sequence: -1,
    dispatch_allowed: false,
    release_status: "NOT_RELEASE"
  };
}
__name(provisionAuthority2Genesis, "provisionAuthority2Genesis");

// authority2-private-genesis-controller.mjs
var H642 = /^[a-f0-9]{64}$/;
var CONTROL_PATH = "/__private_operator/genesis-once";
var HEADERS = { "content-type": "application/json", "cache-control": "no-store" };
var encoder3 = new TextEncoder();
var ControllerHold = class extends Error {
  static {
    __name(this, "ControllerHold");
  }
  constructor(code) {
    super(code);
    this.code = code;
  }
};
var hold3 = /* @__PURE__ */ __name((code) => {
  throw new ControllerHold(code);
}, "hold");
var reply = /* @__PURE__ */ __name((status, body) => new Response(JSON.stringify(body), { status, headers: HEADERS }), "reply");
var notFound = /* @__PURE__ */ __name(() => reply(404, { error: "AUTHORITY2_NO_HTTP_INITIALIZER", dispatch_allowed: false }), "notFound");
function safeCode(error) {
  return typeof error?.code === "string" && /^[A-Z0-9_]{1,100}$/.test(error.code) ? error.code : "A2_PRIVATE_GENESIS_UNCONFIRMED_HOLD";
}
__name(safeCode, "safeCode");
function parse(value, code) {
  if (typeof value !== "string" || encoder3.encode(value).length > 32768) hold3(code);
  try {
    return JSON.parse(value);
  } catch {
    hold3(code);
  }
}
__name(parse, "parse");
function control(env, now = Date.now()) {
  const value = parse(env.HW_GENESIS_CONTROL_JSON, "A2_GENESIS_CONTROL_CONFIG_HOLD");
  exact(value, [
    "schema",
    "approved_cron",
    "not_before_ms",
    "not_after_ms",
    "expected_commitment_sha256",
    "anchor_pin",
    "commitment",
    "anchor_proof"
  ], "GENESIS_CONTROL");
  if (value.schema !== "musitu.axiom.authority2.private-genesis-control.v1" || typeof value.approved_cron !== "string" || value.approved_cron.length > 64 || !/^[0-9*\/,\-]+(?: [0-9*\/,\-]+){4}$/.test(value.approved_cron) || !Number.isSafeInteger(value.not_before_ms) || !Number.isSafeInteger(value.not_after_ms) || value.not_before_ms < 1 || value.not_after_ms - value.not_before_ms < 1 || value.not_after_ms - value.not_before_ms > 9e5 || now < value.not_before_ms || now >= value.not_after_ms || typeof value.expected_commitment_sha256 !== "string" || !H642.test(value.expected_commitment_sha256))
    hold3("A2_GENESIS_APPROVED_WINDOW_HOLD");
  return value;
}
__name(control, "control");
function controlToken(env) {
  if (typeof env.HW_GENESIS_CONTROL_TOKEN !== "string" || !/^[A-Za-z0-9_-]{32,200}$/.test(env.HW_GENESIS_CONTROL_TOKEN))
    hold3("A2_GENESIS_PRIVATE_CONTROL_TOKEN_HOLD");
  return env.HW_GENESIS_CONTROL_TOKEN;
}
__name(controlToken, "controlToken");
async function authenticate(request, env) {
  const supplied = request.headers.get("authorization")?.match(/^Bearer ([A-Za-z0-9_-]{32,200})$/)?.[1];
  const expected = controlToken(env);
  if (!supplied) hold3("A2_GENESIS_PRIVATE_CHANNEL_DENIED");
  const [a, b] = await Promise.all([
    crypto.subtle.digest("SHA-256", encoder3.encode(supplied)),
    crypto.subtle.digest("SHA-256", encoder3.encode(expected))
  ]);
  const aa = new Uint8Array(a), bb = new Uint8Array(b);
  let different = 0;
  for (let i = 0; i < aa.length; i++) different |= aa[i] ^ bb[i];
  if (different) hold3("A2_GENESIS_PRIVATE_CHANNEL_DENIED");
}
__name(authenticate, "authenticate");
async function verifySignerAndRoles(env) {
  const pin = parse(env.HW_CONFIG_JSON, "A2_GENESIS_RUNTIME_PIN_HOLD");
  exact(pin, ["account_id", "ledger_id", "namespace", "key_id", "public_key_jwk"], "GENESIS_RUNTIME_PIN");
  publicKey(pin.public_key_jwk);
  genesisBarrierKey(pin);
  const roles = parse(env.HW_ROLE_TOKEN_SHA256_JSON, "A2_GENESIS_RUNTIME_ROLES_HOLD");
  exact(roles, ["read", "write"], "GENESIS_RUNTIME_ROLES");
  if (typeof roles.read !== "string" || typeof roles.write !== "string" || !H642.test(roles.read) || !H642.test(roles.write) || roles.read === roles.write)
    hold3("A2_GENESIS_RUNTIME_ROLES_HOLD");
  const jwk = parse(env.HW_SIGNING_JWK, "A2_GENESIS_SIGNER_UNAVAILABLE_HOLD");
  if (jwk?.kty !== "OKP" || jwk?.crv !== "Ed25519" || jwk.x !== pin.public_key_jwk.x || typeof jwk.d !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(jwk.d))
    hold3("A2_GENESIS_SIGNER_PIN_HOLD");
  try {
    const key = await crypto.subtle.importKey(
      "jwk",
      { kty: "OKP", crv: "Ed25519", x: jwk.x, d: jwk.d },
      "Ed25519",
      false,
      ["sign"]
    );
    const publicPart = await crypto.subtle.importKey("jwk", pin.public_key_jwk, "Ed25519", false, ["verify"]);
    const challenge = encoder3.encode("AXIOM_AUTHORITY2_PRIVATE_GENESIS_SIGNER_CHECK_V1");
    const signature = await crypto.subtle.sign("Ed25519", key, challenge);
    if (!await crypto.subtle.verify("Ed25519", publicPart, signature, challenge))
      hold3("A2_GENESIS_SIGNER_PIN_HOLD");
  } catch {
    hold3("A2_GENESIS_SIGNER_UNAVAILABLE_HOLD");
  }
  return pin;
}
__name(verifySignerAndRoles, "verifySignerAndRoles");
async function privateBody(request) {
  if (request.headers.get("origin") || request.headers.get("cookie") || request.headers.get("sec-fetch-site") || request.headers.get("content-type") !== "application/json") hold3("A2_GENESIS_PRIVATE_CHANNEL_DENIED");
  const reader = request.body?.getReader();
  if (!reader) hold3("A2_GENESIS_PRIVATE_REQUEST_HOLD");
  let timer, text = "", size = 0;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new ControllerHold(
      "A2_GENESIS_PRIVATE_REQUEST_TIMEOUT_HOLD"
    )), 2e3);
  });
  const decoder = new TextDecoder("utf-8", { fatal: true });
  try {
    for (; ; ) {
      const next = await Promise.race([reader.read(), timeout]);
      if (next.done) break;
      size += next.value.byteLength;
      if (size > 256) hold3("A2_GENESIS_PRIVATE_REQUEST_SIZE_HOLD");
      text += decoder.decode(next.value, { stream: true });
    }
    text += decoder.decode();
    const body = JSON.parse(text);
    exact(body, ["commitment_sha256"], "GENESIS_PRIVATE_REQUEST");
    if (text !== canonicalJson(body)) hold3("A2_GENESIS_PRIVATE_REQUEST_HOLD");
    return body;
  } finally {
    clearTimeout(timer);
    void reader.cancel().catch(() => {
    });
    reader.releaseLock();
  }
}
__name(privateBody, "privateBody");
var Authority2Highwater = class {
  static {
    __name(this, "Authority2Highwater");
  }
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
  }
  async fetch(request) {
    if (request.method !== "POST" || new URL(request.url).pathname !== CONTROL_PATH) return notFound();
    try {
      await authenticate(request, this.env);
      const input = await privateBody(request), approved = control(this.env);
      if (input.commitment_sha256 !== approved.expected_commitment_sha256)
        hold3("A2_GENESIS_PRIVATE_COMMITMENT_HOLD");
      const pin = await verifySignerAndRoles(this.env);
      const result = await provisionAuthority2Genesis({
        storage: this.ctx.storage,
        bucket: this.env.HIGHWATER_WORM,
        pin,
        anchor_pin: approved.anchor_pin,
        commitment: approved.commitment,
        anchor_proof: approved.anchor_proof,
        expected_commitment_sha256: approved.expected_commitment_sha256,
        deadline_ms: approved.not_after_ms,
        anchor_read_token: this.env.HW_GENESIS_GITHUB_READ_TOKEN
      });
      return reply(200, result);
    } catch (error) {
      return reply(503, { error: safeCode(error), dispatch_allowed: false });
    }
  }
};
async function executePrivateGenesisSchedule(controller, env) {
  if (typeof controller?.noRetry !== "function") hold3("A2_GENESIS_SCHEDULE_CONTEXT_HOLD");
  controller.noRetry();
  const approved = control(env), token = controlToken(env);
  if (controller.cron !== approved.approved_cron || !Number.isFinite(controller.scheduledTime) || controller.scheduledTime < approved.not_before_ms || controller.scheduledTime >= approved.not_after_ms)
    hold3("A2_GENESIS_SCHEDULE_CONTEXT_HOLD");
  const pin = await verifySignerAndRoles(env);
  if (await sha256Json(approved.commitment) !== approved.expected_commitment_sha256)
    hold3("A2_GENESIS_APPROVED_HASH_MISMATCH_HOLD");
  const stub = env.HIGHWATER_STATE.get(env.HIGHWATER_STATE.idFromName(
    "highwater/" + pin.ledger_id + "/" + pin.namespace
  ));
  const response = await stub.fetch(new Request("https://authority2-private.invalid" + CONTROL_PATH, {
    method: "POST",
    headers: { authorization: "Bearer " + token, "content-type": "application/json" },
    body: canonicalJson({ commitment_sha256: approved.expected_commitment_sha256 })
  }));
  if (response.status !== 200) hold3("A2_GENESIS_PRIVATE_EXECUTION_HOLD");
  const result = await response.json();
  exact(result, [
    "schema",
    "status",
    "commitment_sha256",
    "barrier_key",
    "initial_sequence",
    "dispatch_allowed",
    "release_status"
  ], "GENESIS_PRIVATE_RESULT");
  if (result.schema !== "musitu.axiom.authority2.genesis-candidate-result.v1" || result.initial_sequence !== -1 || result.barrier_key !== genesisBarrierKey(pin) || result.status !== "PREGENESIS_COMMITTED_CANDIDATE_ONLY" || result.dispatch_allowed !== false || result.release_status !== "NOT_RELEASE" || result.commitment_sha256 !== approved.expected_commitment_sha256)
    hold3("A2_GENESIS_PRIVATE_RESULT_HOLD");
  return result;
}
__name(executePrivateGenesisSchedule, "executePrivateGenesisSchedule");
var authority2_private_genesis_controller_default = {
  fetch() {
    return notFound();
  },
  async scheduled(controller, env) {
    try {
      await executePrivateGenesisSchedule(controller, env);
    } catch (error) {
      throw new ControllerHold(safeCode(error));
    }
  }
};
export {
  Authority2Highwater,
  authority2_private_genesis_controller_default as default,
  executePrivateGenesisSchedule
};
//# sourceMappingURL=authority2-private-genesis-controller.js.map
