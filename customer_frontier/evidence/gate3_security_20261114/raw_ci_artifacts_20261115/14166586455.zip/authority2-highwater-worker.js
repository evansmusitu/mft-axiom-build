var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// authority2-r2-worm.mjs
var SCHEMA = "musitu.axiom.external-highwater.v1";
var H64 = /^[a-f0-9]{64}$/;
var ID = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,179}$/;
var WormHold = class extends Error {
  static {
    __name(this, "WormHold");
  }
  constructor(reason) {
    super(reason);
    this.name = "WormHold";
    this.reason = reason;
  }
};
var hold = /* @__PURE__ */ __name((code) => {
  throw new WormHold(code);
}, "hold");
var canonical = /* @__PURE__ */ __name((x) => Array.isArray(x) ? "[" + x.map(canonical).join(",") + "]" : x && typeof x === "object" ? "{" + Object.keys(x).sort().map((k) => JSON.stringify(k) + ":" + canonical(x[k])).join(",") + "}" : JSON.stringify(x), "canonical");
function wormKey(pin, seq) {
  if (!pin || pin.account_id !== "67469478aa9349fa0a57fe3a72da200a" || !ID.test(pin.ledger_id) || !/^ax-[a-z0-9-]{1,60}$/.test(pin.namespace) || !Number.isSafeInteger(seq) || seq < 0 || seq > 1000001) hold("HIGHWATER_WORM_ID_INVALID_HOLD");
  return `b27/${pin.account_id}/${pin.ledger_id}/${pin.namespace}/${String(seq).padStart(12, "0")}.json`;
}
__name(wormKey, "wormKey");
async function readRecord(bucket, pin, seq) {
  const obj = await bucket.get(wormKey(pin, seq));
  if (!obj) hold("HIGHWATER_WORM_PREDECESSOR_MISSING_HOLD");
  if (!Number.isSafeInteger(obj.size) || obj.size > 4096) hold("HIGHWATER_WORM_OBJECT_SIZE_HOLD");
  let data;
  try {
    data = JSON.parse(await obj.text());
  } catch {
    hold("HIGHWATER_WORM_OBJECT_INVALID_HOLD");
  }
  if (data?.schema !== SCHEMA) hold("HIGHWATER_WORM_SCHEMA_MISMATCH_HOLD");
  if (!data || data.account_id !== pin.account_id || data.ledger_id !== pin.ledger_id || data.namespace !== pin.namespace || data.key_id !== pin.key_id || data.sequence !== seq || !H64.test(data.head)) hold("HIGHWATER_WORM_OBJECT_BINDING_HOLD");
  return data;
}
__name(readRecord, "readRecord");
async function wormReadback(bucket, pin, tip) {
  if (!bucket || typeof bucket.head !== "function" || typeof bucket.get !== "function" || typeof bucket.put !== "function") hold("HIGHWATER_WORM_BINDING_MISSING_HOLD");
  if (!Number.isSafeInteger(tip?.sequence) || tip.sequence < -1 || tip.sequence > 1e6 || !H64.test(tip?.head)) hold("HIGHWATER_WORM_TIP_INVALID_HOLD");
  if (await bucket.head(wormKey(pin, tip.sequence + 1))) hold("HIGHWATER_WORM_ROLLBACK_DETECTED_HOLD");
  if (tip.sequence >= 0) {
    const record = await readRecord(bucket, pin, tip.sequence);
    if (record.head !== tip.head) hold("HIGHWATER_WORM_HEAD_MISMATCH_HOLD");
    if (tip.sequence >= 1) {
      if (record.previous_sequence !== tip.sequence - 1) hold("HIGHWATER_WORM_PREDECESSOR_SEQUENCE_MISMATCH_HOLD");
      if (!H64.test(record.previous_head)) hold("HIGHWATER_WORM_PREDECESSOR_HASH_MISMATCH_HOLD");
      for (const field of ["event_digest", "artifact_sha256", "action_sha256", "challenge"])
        if (!H64.test(record[field])) hold("HIGHWATER_WORM_EVENT_PROOF_INVALID_HOLD");
      if (record.decision !== "ALLOW_ONCE") hold("HIGHWATER_WORM_EVENT_PROOF_INVALID_HOLD");
      const predecessor = await readRecord(bucket, pin, tip.sequence - 1);
      if (record.previous_head !== predecessor.head) hold("HIGHWATER_WORM_PREDECESSOR_HASH_MISMATCH_HOLD");
    }
  }
  return true;
}
__name(wormReadback, "wormReadback");
async function wormAppend(bucket, pin, record) {
  if (!Number.isSafeInteger(record?.sequence) || record.sequence < 0 || record.sequence > 1e6 || record.previous_sequence !== record.sequence - 1 || !H64.test(record?.previous_head) || !H64.test(record?.head)) hold("HIGHWATER_WORM_SEQUENCE_INVALID_HOLD");
  await wormReadback(bucket, pin, { sequence: record.previous_sequence, head: record.previous_head });
  const key = wormKey(pin, record.sequence), body2 = canonical(record);
  if (new TextEncoder().encode(body2).byteLength > 4096) hold("HIGHWATER_WORM_EVENT_OVERSIZE_HOLD");
  const written = await bucket.put(key, body2, { onlyIf: new Headers({ "if-none-match": "*" }), httpMetadata: { contentType: "application/json" } });
  if (!written) hold("HIGHWATER_WORM_DUPLICATE_OR_UNCONFIRMED_HOLD");
  const read = await readRecord(bucket, pin, record.sequence);
  if (canonical(read) !== body2) hold("HIGHWATER_WORM_READBACK_MISMATCH_HOLD");
  await wormReadback(bucket, pin, { sequence: record.sequence, head: record.head });
  return true;
}
__name(wormAppend, "wormAppend");

// authority2-highwater-worker.mjs
var SCHEMA2 = "musitu.axiom.external-highwater.v1";
var H642 = /^[a-f0-9]{64}$/;
var ID2 = /^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,179}$/;
var enc = new TextEncoder();
var headers = { "content-type": "application/json", "cache-control": "no-store", "x-content-type-options": "nosniff" };
var reply = /* @__PURE__ */ __name((status, payload) => new Response(JSON.stringify(payload), { status, headers }), "reply");
function canonical2(x) {
  if (Array.isArray(x)) return "[" + x.map(canonical2).join(",") + "]";
  if (x && typeof x === "object") return "{" + Object.keys(x).sort().map((k) => JSON.stringify(k) + ":" + canonical2(x[k])).join(",") + "}";
  return JSON.stringify(x);
}
__name(canonical2, "canonical");
var Denied = class extends Error {
  static {
    __name(this, "Denied");
  }
  constructor(code, status = 403) {
    super(code);
    this.code = code;
    this.status = status;
  }
};
var deny = /* @__PURE__ */ __name((code, status) => {
  throw new Denied(code, status);
}, "deny");
function exact(x, keys) {
  if (!x || typeof x !== "object" || Array.isArray(x) || Object.keys(x).length !== keys.length || !keys.every((k) => Object.hasOwn(x, k))) deny("HIGHWATER_INVALID_FIELDS_HOLD", 400);
}
__name(exact, "exact");
function config(env) {
  let c;
  try {
    c = JSON.parse(env.HW_CONFIG_JSON);
  } catch {
    deny("HIGHWATER_CONFIG_MISSING_HOLD", 503);
  }
  exact(c, ["account_id", "ledger_id", "namespace", "key_id", "public_key_jwk"]);
  exact(c.public_key_jwk, ["kty", "crv", "x"]);
  if (c.public_key_jwk.kty !== "OKP" || c.public_key_jwk.crv !== "Ed25519" || typeof c.public_key_jwk.x !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(c.public_key_jwk.x))
    deny("HIGHWATER_PUBLIC_SIGNER_PIN_INVALID_HOLD", 503);
  if (c.account_id !== "67469478aa9349fa0a57fe3a72da200a" || !ID2.test(c.ledger_id) || !ID2.test(c.key_id) || !/^ax-[a-z0-9-]{1,60}$/.test(c.namespace)) deny("HIGHWATER_ACCOUNT_PIN_MISMATCH_HOLD", 503);
  return c;
}
__name(config, "config");
async function principal(r, env, role) {
  const value = r.headers.get("authorization")?.match(/^Bearer ([a-zA-Z0-9_-]{32,200})$/)?.[1];
  if (!value) deny("HIGHWATER_AUTH_REQUIRED", 401);
  let registry;
  try {
    registry = JSON.parse(env.HW_ROLE_TOKEN_SHA256_JSON);
  } catch {
    deny("HIGHWATER_CREDENTIAL_CONFIG_HOLD", 503);
  }
  exact(registry, ["write", "read"]);
  if (!H642.test(registry[role]) || registry.write === registry.read) deny("HIGHWATER_CREDENTIAL_CONFIG_HOLD", 503);
  const h = [...new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(value)))].map((x) => x.toString(16).padStart(2, "0")).join("");
  if (h !== registry[role]) deny("HIGHWATER_ROLE_DENIED", 403);
}
__name(principal, "principal");
async function body(req) {
  if (req.headers.get("origin") || req.headers.get("cookie") || req.headers.get("sec-fetch-site"))
    deny("HIGHWATER_SERVER_CHANNEL_ONLY", 403);
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json"))
    deny("HIGHWATER_JSON_REQUIRED", 415);
  const length = req.headers.get("content-length");
  if (length !== null && (!/^(0|[1-9][0-9]*)$/.test(length) || Number(length) > 4096))
    deny("HIGHWATER_BODY_TOO_LARGE", 413);
  if (!req.body || typeof req.body.getReader !== "function") deny("HIGHWATER_JSON_INVALID", 400);
  const reader = req.body.getReader(), decoder = new TextDecoder("utf-8", { fatal: true });
  let timer, text = "", count = 0, complete = false;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(
      () => reject(new Denied("HIGHWATER_BODY_TIMEOUT_HOLD", 503)),
      2e3
    );
  });
  try {
    for (; ; ) {
      const chunk = await Promise.race([reader.read(), deadline]);
      if (chunk.done) {
        complete = true;
        break;
      }
      if (!(chunk.value instanceof Uint8Array)) deny("HIGHWATER_JSON_INVALID", 400);
      count += chunk.value.byteLength;
      if (count > 4096) deny("HIGHWATER_BODY_TOO_LARGE", 413);
      try {
        text += decoder.decode(chunk.value, { stream: true });
      } catch {
        deny("HIGHWATER_JSON_INVALID", 400);
      }
    }
    try {
      text += decoder.decode();
    } catch {
      deny("HIGHWATER_JSON_INVALID", 400);
    }
  } finally {
    clearTimeout(timer);
    if (!complete) try {
      void reader.cancel().catch(() => {
      });
    } catch {
    }
    try {
      reader.releaseLock();
    } catch {
    }
  }
  let x;
  try {
    x = JSON.parse(text);
  } catch {
    deny("HIGHWATER_JSON_INVALID", 400);
  }
  if (canonical2(x) !== text) deny("HIGHWATER_CANONICAL_REQUIRED", 400);
  return x;
}
__name(body, "body");
var base = ["schema", "account_id", "ledger_id", "namespace", "key_id", "challenge"];
var eventKeys = ["sequence", "previous_sequence", "previous_head", "head", "event_digest", "artifact_sha256", "action_sha256"];
function common(v, c) {
  if (v.schema !== SCHEMA2 || v.account_id !== c.account_id || v.ledger_id !== c.ledger_id || v.namespace !== c.namespace || v.key_id !== c.key_id || !H642.test(v.challenge)) deny("HIGHWATER_TRUST_BINDING_DENIED_HOLD", 403);
}
__name(common, "common");
function event(v) {
  for (const k of ["previous_head", "head", "event_digest", "artifact_sha256", "action_sha256"]) if (!H642.test(v[k])) deny("HIGHWATER_INVALID_HASH_HOLD", 400);
  if (!Number.isSafeInteger(v.sequence) || v.sequence < 0 || v.sequence > 1e6 || v.previous_sequence !== v.sequence - 1) deny("HIGHWATER_SEQUENCE_DENIED_HOLD", 409);
}
__name(event, "event");
function base64(buf) {
  return btoa(String.fromCharCode(...new Uint8Array(buf))).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}
__name(base64, "base64");
async function prepareSigner(env) {
  let jwk;
  try {
    jwk = JSON.parse(env.HW_SIGNING_JWK);
  } catch {
    deny("HIGHWATER_SIGNER_UNAVAILABLE_HOLD", 503);
  }
  if (jwk?.kty !== "OKP" || jwk?.crv !== "Ed25519" || !jwk.d || !jwk.x)
    deny("HIGHWATER_SIGNER_UNAVAILABLE_HOLD", 503);
  const approved = config(env).public_key_jwk;
  if (jwk.x !== approved.x)
    deny("HIGHWATER_SIGNER_PIN_MISMATCH_HOLD", 503);
  try {
    const key = await crypto.subtle.importKey(
      "jwk",
      { kty: "OKP", crv: "Ed25519", x: jwk.x, d: jwk.d },
      { name: "Ed25519" },
      false,
      ["sign"]
    );
    await crypto.subtle.sign("Ed25519", key, enc.encode("A2_SIGNER_PRECOMMIT_CHECK_V1"));
    return key;
  } catch {
    deny("HIGHWATER_SIGNER_UNAVAILABLE_HOLD", 503);
  }
}
__name(prepareSigner, "prepareSigner");
async function signed(env, payload, preparedKey) {
  const key = preparedKey ?? await prepareSigner(env);
  try {
    return { payload, signature: base64(await crypto.subtle.sign(
      "Ed25519",
      key,
      enc.encode(canonical2(payload))
    )) };
  } catch {
    deny("HIGHWATER_SIGNER_UNAVAILABLE_HOLD", 503);
  }
}
__name(signed, "signed");
async function boundedWorm(operation) {
  let timer;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Denied("HIGHWATER_WORM_TIMEOUT_HOLD", 503)), 3e3);
  });
  try {
    return await Promise.race([operation(), deadline]);
  } finally {
    clearTimeout(timer);
  }
}
__name(boundedWorm, "boundedWorm");
var Authority2Highwater = class {
  static {
    __name(this, "Authority2Highwater");
  }
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
    this.pin = config(env);
    if (!env.HIGHWATER_WORM) deny("HIGHWATER_WORM_BINDING_REQUIRED_HOLD", 503);
    this.worm = env.HIGHWATER_WORM;
  }
  async fetch(r) {
    try {
      if (r.method !== "POST") return reply(404, { error: "HIGHWATER_ROUTE_NOT_FOUND_HOLD" });
      const path = new URL(r.url).pathname;
      if (!["/v1/highwater/append", "/v1/highwater/readback"].includes(path)) return reply(404, { error: "HIGHWATER_ROUTE_NOT_FOUND_HOLD" });
      await principal(r, this.env, path.endsWith("append") ? "write" : "read");
      const input = await body(r);
      const c = this.pin;
      exact(input, path.endsWith("append") ? [...base, ...eventKeys] : base);
      common(input, c);
      if (path.endsWith("append")) {
        event(input);
        const readySigner = await prepareSigner(this.env);
        const transition = await this.ctx.storage.transaction(async (s) => {
          if (await s.get("highwater/pending")) deny("HIGHWATER_PENDING_RECONCILIATION_HOLD", 503);
          const tip2 = await s.get("highwater/tip");
          if (!tip2 || tip2.ledger_id !== c.ledger_id || tip2.namespace !== c.namespace || tip2.account_id !== c.account_id || tip2.key_id !== c.key_id) deny("HIGHWATER_GENESIS_OR_CONTINUITY_MISSING_HOLD", 503);
          if (tip2.sequence !== input.previous_sequence || tip2.head !== input.previous_head || input.sequence !== tip2.sequence + 1) deny("HIGHWATER_CAS_REPLAY_DENIED_HOLD", 409);
          const record = { ...input, decision: "ALLOW_ONCE" };
          await s.put("highwater/pending", { record, next: { ...tip2, sequence: input.sequence, head: input.head } });
          return record;
        });
        await this.ctx.storage.sync();
        await boundedWorm(() => wormAppend(this.worm, c, transition));
        await this.ctx.storage.transaction(async (s) => {
          const pending = await s.get("highwater/pending");
          if (!pending || canonical2(pending.record) !== canonical2(transition)) deny("HIGHWATER_PENDING_CHANGED_HOLD", 503);
          await s.put("highwater/event/" + String(input.sequence).padStart(12, "0"), transition);
          await s.put("highwater/tip", pending.next);
          await s.delete("highwater/pending");
        });
        await this.ctx.storage.sync();
        return reply(200, await signed(this.env, { ...transition, kind: "commit" }, readySigner));
      }
      if (await this.ctx.storage.get("highwater/pending")) deny("HIGHWATER_PENDING_RECONCILIATION_HOLD", 503);
      const tip = await this.ctx.storage.get("highwater/tip");
      if (!tip || tip.ledger_id !== c.ledger_id || tip.namespace !== c.namespace || tip.account_id !== c.account_id || tip.key_id !== c.key_id) deny("HIGHWATER_GENESIS_OR_CONTINUITY_MISSING_HOLD", 503);
      await boundedWorm(() => wormReadback(this.worm, c, tip));
      const { public_key_jwk: _operatorApprovedPublicKey, ...binding } = c;
      return reply(200, await signed(this.env, { schema: SCHEMA2, ...binding, challenge: input.challenge, kind: "readback", sequence: tip.sequence, head: tip.head }));
    } catch (e) {
      return reply(e instanceof Denied ? e.status : 503, { error: e instanceof Denied ? e.code : "HIGHWATER_UNAVAILABLE_HOLD", dispatch_allowed: false });
    }
  }
};
var authority2_highwater_worker_default = { async fetch(r, env) {
  try {
    const c = config(env);
    return await env.HIGHWATER_STATE.get(env.HIGHWATER_STATE.idFromName("highwater/" + c.ledger_id + "/" + c.namespace)).fetch(r);
  } catch {
    return reply(503, { error: "HIGHWATER_UNAVAILABLE_HOLD", dispatch_allowed: false });
  }
} };
export {
  Authority2Highwater,
  authority2_highwater_worker_default as default
};
//# sourceMappingURL=authority2-highwater-worker.js.map
