// integrations/frontier-staging/protocol.mjs
var ACCOUNT = "67469478aa9349fa0a57fe3a72da200a";
var SCHEMA = "musitu.axiom.frontier.isolated-staging.v1";
var H64 = /^[a-f0-9]{64}$/;
var UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var FORBIDDEN = /* @__PURE__ */ new Set([
  "ccc473f1-fbb5-4b8d-8a24-45f3696ac10f",
  "504029cc-f9a5-495e-818f-63c6144b4ea4",
  "be760b23-2ed1-47aa-92aa-9042ce917bb9",
  "5c092b73-d093-483d-adf9-9883a8c2f063",
  "c023a0a0-472a-4178-ad07-02f1d6b2e122"
]);
var StagingHold = class extends Error {
  constructor(code, status = 503) {
    super(code);
    this.code = code;
    this.status = status;
  }
};
var hold = (code, status) => {
  throw new StagingHold(code, status);
};
function exact(x, keys) {
  if (!x || typeof x !== "object" || Array.isArray(x) || Object.keys(x).length !== keys.length || !keys.every((k) => Object.hasOwn(x, k))) hold("FRONTIER_STAGE_FIELDS_HOLD", 400);
}
function fixtureId(value) {
  if (typeof value !== "string" || !/^fixture_[a-z0-9][a-z0-9_]{0,70}$/.test(value)) hold("FRONTIER_STAGE_FIXTURE_ID_REQUIRED", 400);
  return value;
}
function validateScope(pin) {
  exact(pin, ["schema", "account_id", "database_id", "scope_nonce"]);
  if (pin.schema !== SCHEMA || pin.account_id !== ACCOUNT || typeof pin.database_id !== "string" || !UUID.test(pin.database_id) || FORBIDDEN.has(pin.database_id) || typeof pin.scope_nonce !== "string" || !H64.test(pin.scope_nonce)) hold("FRONTIER_STAGE_TARGET_NOT_ADMITTED");
  return Object.freeze(structuredClone(pin));
}
function canonical(value) {
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (value && typeof value === "object") return "{" + Object.keys(value).sort().map(
    (k) => JSON.stringify(k) + ":" + canonical(value[k])
  ).join(",") + "}";
  if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
  hold("FRONTIER_STAGE_JSON_VALUE_HOLD", 400);
}
async function sha(value) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)))].map(
    (x) => x.toString(16).padStart(2, "0")
  ).join("");
}

// integrations/frontier-staging/client.mjs
function isolatedStagingStore({ pin, origin, token, fetchImpl = fetch, timeoutMs = 5e3 }) {
  const scope = validateScope(structuredClone(pin));
  let url;
  try {
    url = new URL(origin);
  } catch {
    hold("FRONTIER_STAGE_ORIGIN_HOLD");
  }
  if (url.protocol !== "https:" || url.username || url.password || url.port || url.pathname !== "/" || url.search || url.hash || !/^axiom-frontier-stage-[a-z0-9-]{1,50}\.[a-z0-9-]{1,63}\.workers\.dev$/.test(url.hostname))
    hold("FRONTIER_STAGE_ORIGIN_HOLD");
  if (typeof token !== "string" || !/^[A-Za-z0-9_-]{32,200}$/.test(token)) hold("FRONTIER_STAGE_TOKEN_HOLD");
  if (!Number.isInteger(timeoutMs) || timeoutMs < 200 || timeoutMs > 1e4) hold("FRONTIER_STAGE_TIMEOUT_HOLD");
  const endpoint = url.origin;
  async function call(operation, input) {
    fixtureId(input.tenant_id);
    if (operation !== "revoke") fixtureId(input.record_id);
    const payload = { schema: SCHEMA, scope_nonce: scope.scope_nonce, ...input }, body = canonical(payload);
    if (new TextEncoder().encode(body).length > 8192) hold("FRONTIER_STAGE_REQUEST_SIZE_HOLD");
    const abort = new AbortController();
    let timer;
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => {
        abort.abort();
        reject(Error("FRONTIER_STAGE_RESPONSE_AMBIGUOUS_HOLD"));
      }, timeoutMs);
    });
    try {
      const response = await Promise.race([fetchImpl(endpoint + "/v1/staging/" + operation, {
        method: "POST",
        redirect: "manual",
        credentials: "omit",
        cache: "no-store",
        signal: abort.signal,
        headers: { authorization: "Bearer " + token, "content-type": "application/json" },
        body
      }), deadline]);
      if (response.status !== 200) hold("FRONTIER_STAGE_REMOTE_DENIAL_HOLD");
      const reader = response.body?.getReader();
      if (!reader) hold("FRONTIER_STAGE_REPLY_HOLD");
      let raw = "", count = 0, complete = false;
      const decoder = new TextDecoder("utf-8", { fatal: true });
      try {
        for (; ; ) {
          const next = await Promise.race([reader.read(), deadline]);
          if (next.done) {
            complete = true;
            break;
          }
          count += next.value.byteLength;
          if (count > 8192) hold("FRONTIER_STAGE_REPLY_SIZE_HOLD");
          raw += decoder.decode(next.value, { stream: true });
        }
        raw += decoder.decode();
      } finally {
        if (!complete) try {
          void reader.cancel().catch(() => {
          });
        } catch {
        }
        try {
          reader.releaseLock();
        } catch {
        }
      }
      const value = JSON.parse(raw), base = ["schema", "scope_nonce", "tenant_id", "operation"];
      exact(value, operation === "revoke" ? [...base, "revoked_token_sha256", "revoked"] : operation === "read" ? [...base, "record_id", "version", "payload", "payload_sha256"] : [...base, "record_id", "version", "payload_sha256"]);
      if (value.schema !== SCHEMA || value.scope_nonce !== scope.scope_nonce || value.tenant_id !== input.tenant_id || value.operation !== operation) hold("FRONTIER_STAGE_REPLY_BINDING_HOLD");
      if (operation === "revoke") {
        if (value.revoked !== true || value.revoked_token_sha256 !== input.token_sha256) hold("FRONTIER_STAGE_REPLY_BINDING_HOLD");
      } else {
        if (value.record_id !== input.record_id || !Number.isSafeInteger(value.version) || value.version < 1 || !H64.test(value.payload_sha256)) hold("FRONTIER_STAGE_REPLY_BINDING_HOLD");
        if (operation === "put" && (value.version !== input.expected_version + 1 || value.payload_sha256 !== await sha(canonical(input.payload))))
          hold("FRONTIER_STAGE_REPLY_BINDING_HOLD");
        if (operation === "read" && value.payload_sha256 !== await sha(canonical(value.payload))) hold("FRONTIER_STAGE_REPLY_BINDING_HOLD");
      }
      return Object.freeze(value);
    } catch {
      hold("FRONTIER_STAGE_UNCONFIRMED_NO_RETRY_HOLD");
    } finally {
      clearTimeout(timer);
    }
  }
  return Object.freeze({
    put: ({ tenant_id, record_id, expected_version, payload }) => call("put", { tenant_id, record_id, expected_version, payload }),
    read: ({ tenant_id, record_id }) => call("read", { tenant_id, record_id }),
    revoke: ({ tenant_id, token_sha256 }) => call("revoke", { tenant_id, token_sha256 })
  });
}
export {
  isolatedStagingStore
};
