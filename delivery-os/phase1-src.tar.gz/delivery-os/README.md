# MUSITU Delivery OS — Phase 1

First commercial deployment foundation for a Zimbabwe-first courier operations platform.

## What is implemented
- Guarded order/delivery state machine.
- Driver login and assigned delivery feed.
- Offline-first event outbox and idempotent reconciliation contract.
- Collection, en-route, arrival, failed-delivery and delivered flows.
- Photo + signature + GPS proof payload.
- Tamper-evident evidence chain and evidence pack API.
- Dispatcher command surface.
- Public low-data customer tracking.
- OSRM routing and VROOM optimization provider interfaces with deterministic degradation.
- Courier API adapter boundary.
- Flutter Android client source with MapLibre, SQLite, Workmanager, geolocation, image capture and secure token storage.
- Pinned OwnFleet upstream submodule for the mature logistics foundation and continued integration.

## Local core verification
```bash
cd delivery-os
npm test
node scripts/phase1-verify.mjs
npm start
```
Open `http://localhost:8080/command` and `http://localhost:8080/track/trk-demo-1001`.

## Android CI build
The branch workflow creates the Android platform scaffold, applies the required permissions/minSdk, runs `flutter analyze`, `flutter test`, and `flutter build apk --release`.

For local Android development with Flutter installed:
```bash
cd delivery-os/driver_flutter
flutter create --platforms=android --org com.musitu --project-name musitu_driver .
cp android_template/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
flutter pub get
flutter run --dart-define=MUSITU_API_URL=http://10.0.2.2:8080
```

## Client adapter
Set `COURIER_API_URL` and `COURIER_API_TOKEN`. The generic adapter deliberately isolates client-specific schemas from the MUSITU domain model. Concrete endpoint mapping is completed against the client's actual Postman collection without changing the core.

## Production note
This branch is isolated. It does not modify Axiom runtime, public endpoints, protected production state, or the frozen OpenAI submission.
