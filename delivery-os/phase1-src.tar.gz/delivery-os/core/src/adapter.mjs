export class CourierApiAdapter {
  constructor({baseUrl,token,fetchImpl=fetch}){this.baseUrl=(baseUrl||'').replace(/\/$/,'');this.token=token;this.fetchImpl=fetchImpl;}
  async request(path,opts={}){if(!this.baseUrl) throw new Error('COURIER_API_URL not configured');const r=await this.fetchImpl(`${this.baseUrl}${path}`,{...opts,headers:{accept:'application/json','content-type':'application/json',authorization:`Bearer ${this.token||''}`,...opts.headers}});if(!r.ok)throw new Error(`Courier API ${r.status}`);return r.status===204?null:r.json();}
  listAssigned(driverId){return this.request(`/drivers/${encodeURIComponent(driverId)}/deliveries`);}
  updateStatus(orderId,payload){return this.request(`/orders/${encodeURIComponent(orderId)}/status`,{method:'POST',body:JSON.stringify(payload)});}
}
