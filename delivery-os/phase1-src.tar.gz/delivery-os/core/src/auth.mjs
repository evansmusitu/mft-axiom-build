import crypto from 'node:crypto';
const secret=()=>process.env.MUSITU_AUTH_SECRET||'dev-only-change-me';
const b64=v=>Buffer.from(JSON.stringify(v)).toString('base64url');
export function issueToken(subject,role='driver',ttlS=3600){const payload={sub:subject,role,exp:Math.floor(Date.now()/1000)+ttlS};const body=b64(payload);const sig=crypto.createHmac('sha256',secret()).update(body).digest('base64url');return `${body}.${sig}`;}
export function verifyToken(token){const [body,sig]=String(token||'').split('.');if(!body||!sig)throw new Error('invalid token');const expected=crypto.createHmac('sha256',secret()).update(body).digest('base64url');if(!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))throw new Error('invalid token');const p=JSON.parse(Buffer.from(body,'base64url').toString());if(p.exp<Math.floor(Date.now()/1000))throw new Error('expired token');return p;}
