export const Status = Object.freeze({
  CREATED: 'CREATED', ASSIGNED: 'ASSIGNED', COLLECTED: 'COLLECTED',
  EN_ROUTE: 'EN_ROUTE', ARRIVED: 'ARRIVED', DELIVERED: 'DELIVERED',
  FAILED: 'FAILED', CANCELLED: 'CANCELLED'
});

const transitions = new Map([
  [Status.CREATED, new Set([Status.ASSIGNED, Status.CANCELLED])],
  [Status.ASSIGNED, new Set([Status.COLLECTED, Status.FAILED, Status.CANCELLED])],
  [Status.COLLECTED, new Set([Status.EN_ROUTE, Status.ARRIVED, Status.FAILED])],
  [Status.EN_ROUTE, new Set([Status.ARRIVED, Status.FAILED])],
  [Status.ARRIVED, new Set([Status.DELIVERED, Status.FAILED])],
  [Status.FAILED, new Set([Status.ASSIGNED, Status.CANCELLED])],
  [Status.DELIVERED, new Set()], [Status.CANCELLED, new Set()]
]);

export function assertTransition(from, to) {
  if (!transitions.has(from) || !transitions.get(from).has(to)) {
    const err = new Error(`invalid transition ${from} -> ${to}`);
    err.code = 'INVALID_TRANSITION'; throw err;
  }
  return true;
}

export function requiresProof(status) { return status === Status.DELIVERED; }

export function validateDeliveryProof(proof) {
  const missing = [];
  if (!proof?.recipientName?.trim()) missing.push('recipientName');
  if (!proof?.photoHash) missing.push('photoHash');
  if (!proof?.signatureHash) missing.push('signatureHash');
  if (!Number.isFinite(proof?.lat) || !Number.isFinite(proof?.lon)) missing.push('gps');
  if (!proof?.capturedAt) missing.push('capturedAt');
  if (missing.length) { const e = new Error(`missing proof: ${missing.join(',')}`); e.code='INVALID_PROOF'; e.missing=missing; throw e; }
  return true;
}
