import crypto from 'node:crypto';

export function canonicalize(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonicalize(value[k])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}
export const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
export const hashArtifact = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

export function sealEvent(event, previousHash='GENESIS') {
  const payload = {...event}; delete payload.hash; delete payload.previousHash;
  const hash = sha256(`${previousHash}|${canonicalize(payload)}`);
  return {...payload, previousHash, hash};
}

export function verifyChain(events) {
  let prev='GENESIS';
  for (const event of events) {
    const sealed=sealEvent(event, prev);
    if (sealed.hash !== event.hash || event.previousHash !== prev) return false;
    prev=event.hash;
  }
  return true;
}
