import { haversine } from './routing.mjs';
export class OptimizerClient {
  constructor(base=process.env.VROOM_URL||'http://localhost:3000'){this.base=base.replace(/\/$/,'');}
  async optimize(input, fetchImpl=fetch){
    try{const r=await fetchImpl(this.base,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(input)});if(!r.ok)throw new Error(`VROOM ${r.status}`);const j=await r.json();return {provider:'vroom',...j};}
    catch(e){return {provider:'heuristic-fallback',warning:String(e.message||e),routes:this.#fallback(input)};}
  }
  #fallback({vehicles=[],jobs=[]}){if(!vehicles.length)return[];const remaining=[...jobs];return vehicles.map(v=>{let current={lat:v.start?.[1]??-17.8292,lon:v.start?.[0]??31.0522};const steps=[];while(remaining.length){remaining.sort((a,b)=>haversine(current,{lat:a.location[1],lon:a.location[0]})-haversine(current,{lat:b.location[1],lon:b.location[0]}));const j=remaining.shift();steps.push({type:'job',job:j.id});current={lat:j.location[1],lon:j.location[0]};}return {vehicle:v.id,steps};});}
}
