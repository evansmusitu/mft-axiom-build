const R=6371e3; const rad=x=>x*Math.PI/180;
export function haversine(a,b){const p1=rad(a.lat),p2=rad(b.lat),dp=rad(b.lat-a.lat),dl=rad(b.lon-a.lon);const h=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.atan2(Math.sqrt(h),Math.sqrt(1-h));}
export class RoutingClient {
  constructor(base=process.env.OSRM_URL||'http://localhost:5000'){this.base=base.replace(/\/$/,'');}
  async route(points, fetchImpl=fetch){
    if(points.length<2) throw new Error('route requires >=2 points');
    const coords=points.map(p=>`${p.lon},${p.lat}`).join(';');
    try{const r=await fetchImpl(`${this.base}/route/v1/driving/${coords}?overview=false&steps=false`); if(!r.ok) throw new Error(`OSRM ${r.status}`); const j=await r.json(); const x=j.routes?.[0]; if(!x) throw new Error('OSRM no route'); return {provider:'osrm',distanceM:x.distance,durationS:x.duration};}
    catch(e){let d=0;for(let i=1;i<points.length;i++)d+=haversine(points[i-1],points[i]); return {provider:'haversine-fallback',distanceM:Math.round(d),durationS:Math.round(d/8.3),warning:String(e.message||e)};}
  }
}
