import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DeliveryStore } from './store.mjs';
import { issueToken, verifyToken } from './auth.mjs';
import { OptimizerClient } from './optimizer.mjs';
import { RoutingClient } from './routing.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '../..');
const evidenceDir = path.join(root, 'data', 'evidence');
fs.mkdirSync(evidenceDir, { recursive: true });

export const store = new DeliveryStore();
store.assign('ord-1001', 'drv-001');
const optimizer = new OptimizerClient();
const routing = new RoutingClient();

const json = (res, status, body) => {
  res.writeHead(status, {
    'content-type': 'application/json',
    'access-control-allow-origin': '*',
  });
  res.end(JSON.stringify(body));
};

const readBody = (req) => new Promise((resolve, reject) => {
  let size = 0;
  const chunks = [];
  req.on('data', (chunk) => {
    size += chunk.length;
    if (size > 2_000_000) {
      reject(new Error('body too large'));
      req.destroy();
      return;
    }
    chunks.push(chunk);
  });
  req.on('end', () => {
    try {
      const raw = Buffer.concat(chunks).toString('utf8');
      resolve(raw ? JSON.parse(raw) : {});
    } catch (error) {
      reject(error);
    }
  });
  req.on('error', reject);
});

const readBytes = (req, max = 10_000_000) => new Promise((resolve, reject) => {
  let size = 0;
  const chunks = [];
  req.on('data', (chunk) => {
    size += chunk.length;
    if (size > max) {
      reject(new Error('artifact too large'));
      req.destroy();
      return;
    }
    chunks.push(chunk);
  });
  req.on('end', () => resolve(Buffer.concat(chunks)));
  req.on('error', reject);
});

const auth = (req, tokenOverride) => verifyToken(
  tokenOverride || (req.headers.authorization || '').replace(/^Bearer\s+/i, ''),
);

function staticFile(res, file, type) {
  try {
    const data = fs.readFileSync(file);
    res.writeHead(200, { 'content-type': type, 'cache-control': 'no-store' });
    res.end(data);
  } catch {
    json(res, 404, { error: 'not found' });
  }
}

export function makeServer() {
  return http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://local');
      if (req.method === 'OPTIONS') {
        res.writeHead(204, {
          'access-control-allow-origin': '*',
          'access-control-allow-headers': 'authorization,content-type,x-artifact-kind,x-artifact-sha256',
          'access-control-allow-methods': 'GET,POST,OPTIONS',
        });
        return res.end();
      }
      if (u.pathname === '/health') {
        return json(res, 200, { ok: true, service: 'musitu-delivery-core', phase: 1 });
      }
      if (u.pathname === '/api/v1/auth/login' && req.method === 'POST') {
        const body = await readBody(req);
        const id = body.driverId || 'drv-001';
        return json(res, 200, { accessToken: issueToken(id, 'driver'), driverId: id });
      }
      if (u.pathname === '/api/v1/dispatcher/login' && req.method === 'POST') {
        return json(res, 200, { accessToken: issueToken('dispatcher', 'dispatcher') });
      }
      if (u.pathname === '/api/v1/driver/assignments') {
        const principal = auth(req);
        const orders = store.snapshot().orders.filter(
          (o) => o.driverId === principal.sub && !['DELIVERED', 'CANCELLED'].includes(o.status),
        );
        return json(res, 200, { orders });
      }
      if (u.pathname === '/api/v1/sync/events' && req.method === 'POST') {
        auth(req);
        const body = await readBody(req);
        const results = [];
        for (const event of body.events || []) {
          results.push({ eventId: event.eventId, ...store.applyClientEvent(event) });
        }
        return json(res, 200, { results, serverVersion: store.version });
      }
      if (u.pathname === '/api/v1/evidence/artifacts' && req.method === 'POST') {
        auth(req);
        const bytes = await readBytes(req);
        if (!bytes.length) return json(res, 400, { error: 'empty artifact' });
        const sha256 = crypto.createHash('sha256').update(bytes).digest('hex');
        const claimed = `${req.headers['x-artifact-sha256'] || ''}`.toLowerCase();
        if (claimed && claimed !== sha256) {
          return json(res, 409, { error: 'artifact hash mismatch', sha256 });
        }
        const kind = `${req.headers['x-artifact-kind'] || 'artifact'}`.replace(/[^a-z0-9_-]/gi, '_');
        const target = path.join(evidenceDir, `${sha256}.${kind}.bin`);
        if (!fs.existsSync(target)) fs.writeFileSync(target, bytes, { flag: 'wx' });
        return json(res, 201, { sha256, kind, size: bytes.length });
      }
      if (u.pathname === '/api/v1/dispatcher/snapshot') {
        const principal = auth(req);
        if (principal.role !== 'dispatcher') return json(res, 403, { error: 'forbidden' });
        return json(res, 200, store.snapshot());
      }
      if (u.pathname === '/api/v1/dispatcher/stream') {
        const principal = auth(req, u.searchParams.get('token') || undefined);
        if (principal.role !== 'dispatcher') return json(res, 403, { error: 'forbidden' });
        res.writeHead(200, {
          'content-type': 'text/event-stream',
          'cache-control': 'no-cache',
          connection: 'keep-alive',
          'access-control-allow-origin': '*',
        });
        const send = (snapshot) => res.write(`event: snapshot\ndata: ${JSON.stringify(snapshot)}\n\n`);
        send(store.snapshot());
        store.on('change', send);
        const heartbeat = setInterval(() => res.write(': ping\n\n'), 20_000);
        req.on('close', () => {
          clearInterval(heartbeat);
          store.off('change', send);
        });
        return;
      }
      if (u.pathname.startsWith('/api/v1/dispatcher/assign/') && req.method === 'POST') {
        const principal = auth(req);
        if (principal.role !== 'dispatcher') return json(res, 403, { error: 'forbidden' });
        const id = decodeURIComponent(u.pathname.split('/').pop());
        const body = await readBody(req);
        return json(res, 200, store.assign(id, body.driverId));
      }
      if (u.pathname.startsWith('/api/v1/track/')) {
        const token = decodeURIComponent(u.pathname.split('/').pop());
        const tracking = store.tracking(token);
        return tracking ? json(res, 200, tracking) : json(res, 404, { error: 'not found' });
      }
      if (u.pathname.startsWith('/api/v1/evidence/')) {
        const principal = auth(req);
        if (!['dispatcher', 'driver'].includes(principal.role)) {
          return json(res, 403, { error: 'forbidden' });
        }
        return json(
          res,
          200,
          store.evidencePack(decodeURIComponent(u.pathname.split('/').pop())),
        );
      }
      if (u.pathname === '/api/v1/route' && req.method === 'POST') {
        auth(req);
        return json(res, 200, await routing.route((await readBody(req)).points || []));
      }
      if (u.pathname === '/api/v1/optimize' && req.method === 'POST') {
        const principal = auth(req);
        if (principal.role !== 'dispatcher') return json(res, 403, { error: 'forbidden' });
        return json(res, 200, await optimizer.optimize(await readBody(req)));
      }
      if (u.pathname === '/' || u.pathname === '/command') {
        return staticFile(res, path.join(root, 'web/command/index.html'), 'text/html; charset=utf-8');
      }
      if (u.pathname === '/command/app.js') {
        return staticFile(res, path.join(root, 'web/command/app.js'), 'text/javascript');
      }
      if (u.pathname === '/command/styles.css') {
        return staticFile(res, path.join(root, 'web/command/styles.css'), 'text/css');
      }
      if (u.pathname === '/track' || u.pathname.startsWith('/track/')) {
        return staticFile(res, path.join(root, 'web/track/index.html'), 'text/html; charset=utf-8');
      }
      if (u.pathname === '/track/app.js') {
        return staticFile(res, path.join(root, 'web/track/app.js'), 'text/javascript');
      }
      if (u.pathname === '/track/styles.css') {
        return staticFile(res, path.join(root, 'web/track/styles.css'), 'text/css');
      }
      return json(res, 404, { error: 'not found' });
    } catch (error) {
      return json(
        res,
        error.code === 'NOT_FOUND'
          ? 404
          : error.code === 'INVALID_TRANSITION' || error.code === 'INVALID_PROOF'
            ? 409
            : 400,
        {
          error: error.message,
          code: error.code || 'BAD_REQUEST',
          missing: error.missing,
        },
      );
    }
  });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 8080);
  makeServer().listen(port, () => console.log(`MUSITU Delivery Core listening on ${port}`));
}
