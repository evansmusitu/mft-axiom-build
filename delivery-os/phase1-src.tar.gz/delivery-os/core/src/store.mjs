import { EventEmitter } from 'node:events';
import { Status, assertTransition, validateDeliveryProof } from './domain.mjs';
import { sealEvent, verifyChain } from './evidence.mjs';

export class DeliveryStore extends EventEmitter {
  constructor(seed = true) {
    super();
    this.orders = new Map();
    this.events = [];
    this.eventIds = new Set();
    this.version = 0;
    this.drivers = new Map([
      ['drv-001', {
        id: 'drv-001',
        name: 'Tariro',
        online: true,
        lat: -17.8292,
        lon: 31.0522,
        capacity: 20,
      }],
    ]);
    if (seed) {
      this.createOrder({
        id: 'ord-1001',
        trackingToken: 'trk-demo-1001',
        customer: 'Demo Customer',
        phone: '+263770000000',
        address: 'Harare CBD · landmark: Eastgate',
        lat: -17.8318,
        lon: 31.0506,
        priority: 2,
      });
    }
  }

  createOrder(input) {
    if (this.orders.has(input.id)) return this.orders.get(input.id);
    const order = {
      ...input,
      status: Status.CREATED,
      version: 1,
      driverId: null,
      proof: null,
      history: [],
    };
    this.orders.set(order.id, order);
    this.#record({
      eventId: `create:${order.id}`,
      orderId: order.id,
      type: 'CREATED',
      actor: 'system',
      at: new Date().toISOString(),
    });
    return order;
  }

  assign(orderId, driverId) {
    const order = this.#get(orderId);
    if (!this.drivers.has(driverId)) {
      throw Object.assign(new Error('unknown driver'), { code: 'NOT_FOUND' });
    }
    assertTransition(order.status, Status.ASSIGNED);
    order.status = Status.ASSIGNED;
    order.driverId = driverId;
    order.version++;
    this.#record({
      eventId: `assign:${orderId}:${order.version}`,
      orderId,
      type: 'ASSIGNED',
      actor: 'dispatcher',
      driverId,
      at: new Date().toISOString(),
    });
    return order;
  }

  applyClientEvent(evt) {
    if (!evt?.eventId) {
      throw Object.assign(new Error('eventId required'), { code: 'BAD_EVENT' });
    }
    if (this.eventIds.has(evt.eventId)) {
      return { accepted: true, duplicate: true, order: this.#get(evt.orderId) };
    }
    const order = this.#get(evt.orderId);
    if (evt.expectedVersion != null && evt.expectedVersion !== order.version) {
      return {
        accepted: false,
        conflict: true,
        serverVersion: order.version,
        order,
      };
    }
    if (evt.type === Status.DELIVERED) validateDeliveryProof(evt.proof);
    assertTransition(order.status, evt.type);
    order.status = evt.type;
    order.version++;
    if (evt.proof) order.proof = evt.proof;
    this.#record({
      ...evt,
      actor: evt.actor || 'driver',
      at: evt.at || new Date().toISOString(),
    });
    return { accepted: true, duplicate: false, order };
  }

  snapshot() {
    return {
      version: this.version,
      orders: [...this.orders.values()],
      drivers: [...this.drivers.values()],
      events: this.events.slice(-200),
    };
  }

  tracking(token) {
    const order = [...this.orders.values()].find((x) => x.trackingToken === token);
    if (!order) return null;
    return {
      id: order.id,
      status: order.status,
      address: order.address,
      driverId: order.driverId,
      proof: order.proof
        ? {
            capturedAt: order.proof.capturedAt,
            recipientName: order.proof.recipientName,
          }
        : null,
      version: order.version,
    };
  }

  evidencePack(orderId) {
    const order = this.#get(orderId);
    const events = this.events.filter((e) => e.orderId === orderId);
    return { order, events, chainValid: verifyChain(this.events) };
  }

  #get(id) {
    const order = this.orders.get(id);
    if (!order) throw Object.assign(new Error('order not found'), { code: 'NOT_FOUND' });
    return order;
  }

  #record(evt) {
    const sealed = sealEvent(evt, this.events.at(-1)?.hash || 'GENESIS');
    this.events.push(sealed);
    this.eventIds.add(evt.eventId);
    this.version++;
    const order = this.orders.get(evt.orderId);
    if (order) order.history.push(evt.eventId);
    queueMicrotask(() => this.emit('change', this.snapshot()));
    return sealed;
  }
}
