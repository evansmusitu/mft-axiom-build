import test from 'node:test';import assert from 'node:assert/strict';import {issueToken,verifyToken} from '../src/auth.mjs';
test('signed token verifies',()=>{const t=issueToken('drv-001','driver');assert.equal(verifyToken(t).sub,'drv-001');});
test('tampered token rejected',()=>{const t=issueToken('drv-001');assert.throws(()=>verifyToken(t+'x'));});
