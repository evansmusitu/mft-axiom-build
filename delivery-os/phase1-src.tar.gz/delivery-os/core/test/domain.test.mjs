import test from 'node:test';import assert from 'node:assert/strict';import {Status,assertTransition,validateDeliveryProof} from '../src/domain.mjs';
test('valid transition',()=>assert.equal(assertTransition(Status.CREATED,Status.ASSIGNED),true));
test('invalid transition fails closed',()=>assert.throws(()=>assertTransition(Status.CREATED,Status.DELIVERED),/invalid transition/));
test('delivery proof requires photo signature gps recipient',()=>assert.throws(()=>validateDeliveryProof({recipientName:'A'}),/missing proof/));
test('complete proof accepted',()=>assert.equal(validateDeliveryProof({recipientName:'A',photoHash:'p',signatureHash:'s',lat:-17.8,lon:31.0,capturedAt:'2026-10-06T00:00:00Z'}),true));
