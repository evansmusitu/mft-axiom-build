import test from 'node:test';import assert from 'node:assert/strict';import {sealEvent,verifyChain,canonicalize} from '../src/evidence.mjs';
test('canonical object order stable',()=>assert.equal(canonicalize({b:2,a:1}),canonicalize({a:1,b:2})));
test('hash chain verifies and tamper fails',()=>{const a=sealEvent({eventId:'1',x:1});const b=sealEvent({eventId:'2',x:2},a.hash);assert.equal(verifyChain([a,b]),true);b.x=9;assert.equal(verifyChain([a,b]),false);});
