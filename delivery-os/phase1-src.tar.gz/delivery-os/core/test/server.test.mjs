import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { makeServer } from '../src/server.mjs';

async function withServer(fn) {
  const server = makeServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  try {
    await fn(`http://127.0.0.1:${server.address().port}`);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
}

async function driverLogin(base) {
  const response = await fetch(`${base}/api/v1/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: '{}',
  });
  return response.json();
}

test('health and authenticated assignment flow', () => withServer(async (base) => {
  let response = await fetch(`${base}/health`);
  assert.equal(response.status, 200);
  const login = await driverLogin(base);
  response = await fetch(`${base}/api/v1/driver/assignments`, {
    headers: { authorization: `Bearer ${login.accessToken}` },
  });
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.ok(body.orders.length >= 1);
  assert.equal(body.orders[0].driverId, 'drv-001');
}));

test('public tracking token works without auth', () => withServer(async (base) => {
  const response = await fetch(`${base}/api/v1/track/trk-demo-1001`);
  assert.equal(response.status, 200);
  assert.equal((await response.json()).id, 'ord-1001');
}));

test('evidence artifact upload verifies content hash', () => withServer(async (base) => {
  const login = await driverLogin(base);
  const bytes = Buffer.from('proof-photo-test');
  const digest = crypto.createHash('sha256').update(bytes).digest('hex');
  const response = await fetch(`${base}/api/v1/evidence/artifacts`, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${login.accessToken}`,
      'content-type': 'application/octet-stream',
      'x-artifact-kind': 'photo',
      'x-artifact-sha256': digest,
    },
    body: bytes,
  });
  assert.equal(response.status, 201);
  const body = await response.json();
  assert.equal(body.sha256, digest);
  assert.equal(body.size, bytes.length);
}));
