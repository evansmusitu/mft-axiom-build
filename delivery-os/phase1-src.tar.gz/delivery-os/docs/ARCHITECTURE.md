# Phase-1 architecture

`Courier REST API -> MUSITU Adapter -> Delivery Core -> Driver / Command / Track`

The upstream OwnFleet submodule provides the mature reference/foundation for NestJS/PostGIS/Redis/dashboard logistics capabilities. MUSITU's Phase-1 executable compatibility layer is deliberately independent at first so client integration can be tested without requiring the courier's private API or infrastructure.

## State authority
Existing courier orders/customers remain authoritative through the adapter. MUSITU maintains delivery execution state, idempotent device events, proof/evidence and operational projections.

## Offline contract
Driver actions are durable locally before network transmission. Events carry `eventId`, `orderId`, `expectedVersion`, `type`, payload and timestamp. The server accepts duplicates idempotently and rejects stale versions as conflicts.

## Evidence
Each server event is canonicalized and SHA-256 chained to the prior authoritative event. Photo/signature content hashes are stored in the proof payload. A full parcel evidence pack can be reconstructed.

## Routing / optimization
OSRM and VROOM are providers, not authorities. If either provider is unavailable, the current Phase-1 core degrades to deterministic fallback logic so critical delivery completion remains available; production deployment should run self-hosted routing infrastructure.
