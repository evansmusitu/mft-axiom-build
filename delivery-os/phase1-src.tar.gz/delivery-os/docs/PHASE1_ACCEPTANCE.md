# MUSITU Delivery OS — Phase 1 Acceptance

## Contract floor
- [ ] Android release APK builds in CI.
- [x] Driver authentication path.
- [x] Assigned-deliveries work queue.
- [x] Collection / en-route / arrival / delivery transitions.
- [x] Photo + recipient signature + GPS + recipient name proof.
- [x] Proof artifacts upload as bytes and are SHA-256 verified server-side.
- [x] Public tokenized tracking endpoint/surface.
- [x] Client REST adapter boundary.
- [x] Source + handover/run instructions.
- [ ] Exact courier REST/Postman schema binding — blocked on the client's actual Postman collection/API contract, which has not been supplied.

## Reliability / operational foundation
- [x] Explicit delivery state machine; unknown/invalid transitions fail closed.
- [x] Offline SQLite outbox; UI commits locally before network synchronization.
- [x] Sequential offline state versions allow multi-step replay without self-conflict.
- [x] Idempotency through unique event IDs.
- [x] Optimistic version conflicts fail rather than overwrite.
- [x] Background sync via Workmanager.
- [x] Tamper-evident SHA-256 event chain and evidence pack endpoint.
- [x] OSRM adapter with deterministic degraded-mode fallback.
- [x] VROOM adapter with deterministic degraded-mode fallback.
- [x] Dispatcher command surface with SSE realtime stream.
- [x] Low-data customer tracking surface.
- [x] Zimbabwe-first destination model supports landmark text + coordinates.

## Foundation parity source
The production-grade logistics baseline is the pinned OwnFleet MIT foundation at commit `98744125c827b6e5bbe2af384c3ef9308c445ec8`, which supplies PostgreSQL/PostGIS, Redis/Bull, multi-tenancy, WebSockets, routing/ETA, dispatch, geo-POD, customer tracking, analytics, observability, backups and the manager platform. CI must run its API/web test and build gates; the MUSITU overlay adds Flutter, offline semantics, signature capture, evidence chaining, VROOM integration boundary, and client adapter isolation.

## Security baseline
- [x] Signed bearer tokens for the Phase-1 overlay service.
- [x] Role gate on dispatcher endpoints.
- [x] No committed production secrets.
- [x] JSON and artifact size limits.
- [x] Invalid transitions/proof fail closed.
- [x] Secure mobile token storage.
- [x] Artifact content hash verification.
- [ ] Production identity provider / rotated signing keys — deployment configuration.
- [ ] External security review — required before public production exposure.

## Release evidence required
Phase 1 is only internally complete when CI reports:
1. Pinned OwnFleet API tests PASS.
2. Pinned OwnFleet web tests PASS.
3. Pinned OwnFleet API + web builds PASS.
4. MUSITU Node verification PASS.
5. Flutter analyze PASS.
6. Flutter test PASS.
7. Android release APK build PASS.

Customer-specific acceptance remains blocked until the real courier API/Postman collection and credentials are provided; no fake integration result is permitted.
