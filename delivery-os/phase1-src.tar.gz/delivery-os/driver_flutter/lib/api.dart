import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'models.dart';
import 'offline_outbox.dart';

class ApiClient {
  ApiClient(this.baseUrl, this.outbox);

  final String baseUrl;
  final OfflineOutbox outbox;
  final _secure = const FlutterSecureStorage();

  Future<String?> get token => _secure.read(key: 'access_token');

  Future<void> login([String driverId = 'drv-001']) async {
    final r = await http.post(
      Uri.parse('$baseUrl/api/v1/auth/login'),
      headers: {'content-type': 'application/json'},
      body: jsonEncode({'driverId': driverId}),
    );
    if (r.statusCode != 200) throw Exception('Login failed ${r.statusCode}');
    final j = jsonDecode(r.body) as Map<String, dynamic>;
    await _secure.write(key: 'access_token', value: j['accessToken'] as String);
  }

  Future<Map<String, String>> _headers() async => {
        'content-type': 'application/json',
        'authorization': 'Bearer ${await token ?? ''}',
      };

  Future<List<DeliveryOrder>> assignments() async {
    try {
      var r = await http.get(
        Uri.parse('$baseUrl/api/v1/driver/assignments'),
        headers: await _headers(),
      );
      if (r.statusCode == 401) {
        await login();
        r = await http.get(
          Uri.parse('$baseUrl/api/v1/driver/assignments'),
          headers: await _headers(),
        );
      }
      if (r.statusCode != 200) throw Exception('Assignments ${r.statusCode}');
      final j = jsonDecode(r.body) as Map<String, dynamic>;
      await outbox.cacheJson('assignments', j['orders']);
      return (j['orders'] as List)
          .map((x) => DeliveryOrder.fromJson(x as Map<String, dynamic>))
          .toList();
    } catch (_) {
      final c = await outbox.readCache('assignments');
      if (c is List) {
        return c
            .map((x) => DeliveryOrder.fromJson(Map<String, dynamic>.from(x as Map)))
            .toList();
      }
      rethrow;
    }
  }

  Future<String> uploadArtifact(Uint8List bytes, String kind) async {
    final hash = sha256.convert(bytes).toString();
    final h = await _headers();
    h['content-type'] = 'application/octet-stream';
    h['x-artifact-kind'] = kind;
    h['x-artifact-sha256'] = hash;
    final r = await http.post(
      Uri.parse('$baseUrl/api/v1/evidence/artifacts'),
      headers: h,
      body: bytes,
    );
    if (r.statusCode != 201) throw Exception('Artifact upload ${r.statusCode}');
    final j = jsonDecode(r.body) as Map<String, dynamic>;
    return j['sha256'] as String;
  }

  Future<int> sync() async {
    final events = await outbox.pending();
    if (events.isEmpty) return 0;
    final r = await http.post(
      Uri.parse('$baseUrl/api/v1/sync/events'),
      headers: await _headers(),
      body: jsonEncode({'events': events.map((e) => e.toJson()).toList()}),
    );
    if (r.statusCode != 200) throw Exception('Sync ${r.statusCode}');
    final j = jsonDecode(r.body) as Map<String, dynamic>;
    final acked = <String>[];
    for (final raw in (j['results'] as List)) {
      final x = raw as Map<String, dynamic>;
      if (x['accepted'] == true) acked.add(x['eventId'] as String);
      if (x['conflict'] == true) {
        throw Exception('Sync conflict for ${x['eventId']}; refresh required');
      }
    }
    await outbox.ack(acked);
    return acked.length;
  }
}
