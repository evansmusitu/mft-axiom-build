import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:signature/signature.dart';
import 'package:workmanager/workmanager.dart';
import 'api.dart';
import 'models.dart';
import 'offline_outbox.dart';

const apiBase = String.fromEnvironment(
  'MUSITU_API_URL',
  defaultValue: 'http://10.0.2.2:8080',
);

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, input) async {
    try {
      final outbox = OfflineOutbox();
      final api = ApiClient(apiBase, outbox);
      await api.sync();
      return true;
    } catch (_) {
      return false;
    }
  });
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Workmanager().initialize(callbackDispatcher);
  runApp(const MusituDriverApp());
}

class MusituDriverApp extends StatelessWidget {
  const MusituDriverApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'MUSITU Driver',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xffa8d84e),
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: const Color(0xff07111c),
          useMaterial3: true,
        ),
        home: const DriverHome(),
      );
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});

  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final outbox = OfflineOutbox();
  late final ApiClient api = ApiClient(apiBase, outbox);
  List<DeliveryOrder> orders = [];
  bool loading = true;
  String notice = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      if (await api.token == null) await api.login();
      final next = await api.assignments();
      if (mounted) setState(() => orders = next);
    } catch (_) {
      if (mounted) setState(() => notice = 'Offline mode · cached work only');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<DeliveryOrder> _queue(
    DeliveryOrder order,
    String type, {
    Map<String, dynamic>? payload,
  }) async {
    final e = OutboxEvent(
      eventId: '${DateTime.now().microsecondsSinceEpoch}:${order.id}:$type',
      orderId: order.id,
      expectedVersion: order.version,
      type: type,
      payload: payload ?? const {},
      createdAt: DateTime.now().toUtc().toIso8601String(),
    );
    await outbox.enqueue(e);
    try {
      await api.sync();
      notice = 'Synced';
    } catch (_) {
      notice = 'Saved offline · sync queued';
      await Workmanager().registerOneOffTask(
        'sync-${e.eventId}',
        'sync-outbox',
      );
    }
    final advanced = order.advance(type);
    setState(() {
      orders = orders.map((x) => x.id == advanced.id ? advanced : x).toList();
    });
    return advanced;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('MUSITU Driver'),
          actions: [
            IconButton(
              onPressed: () async {
                try {
                  await api.sync();
                } finally {
                  await _load();
                }
              },
              icon: const Icon(Icons.sync),
            ),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: _load,
                child: ListView(
                  padding: const EdgeInsets.all(14),
                  children: [
                    if (notice.isNotEmpty)
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(notice),
                        ),
                      ),
                    SizedBox(
                      height: 210,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: MapLibreMap(
                          styleString: MapLibreStyles.openfreemapLiberty,
                          initialCameraPosition: CameraPosition(
                            target: LatLng(-17.8292, 31.0522),
                            zoom: 12,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    ...orders.map(
                      (order) => Card(
                        child: ListTile(
                          title: Text(order.id),
                          subtitle: Text(
                            '${order.address}\n${order.status} · v${order.version}',
                          ),
                          isThreeLine: true,
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DeliveryScreen(
                                order: order,
                                onQueue: _queue,
                                api: api,
                              ),
                            ),
                          ).then((_) => _load()),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
      );
}

typedef QueueFn = Future<DeliveryOrder> Function(
  DeliveryOrder order,
  String type, {
  Map<String, dynamic>? payload,
});

class DeliveryScreen extends StatefulWidget {
  const DeliveryScreen({
    super.key,
    required this.order,
    required this.onQueue,
    required this.api,
  });

  final DeliveryOrder order;
  final QueueFn onQueue;
  final ApiClient api;

  @override
  State<DeliveryScreen> createState() => _DeliveryScreenState();
}

class _DeliveryScreenState extends State<DeliveryScreen> {
  final sig = SignatureController(penStrokeWidth: 3);
  final name = TextEditingController();
  XFile? photo;
  Position? pos;
  bool busy = false;
  late DeliveryOrder order = widget.order;

  @override
  void dispose() {
    sig.dispose();
    name.dispose();
    super.dispose();
  }

  Future<void> _gps() async {
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      throw Exception('Location permission required for proof of delivery');
    }
    pos = await Geolocator.getCurrentPosition();
  }

  Future<void> _advance(String type, {Map<String, dynamic>? payload}) async {
    final next = await widget.onQueue(order, type, payload: payload);
    if (mounted) setState(() => order = next);
  }

  Future<void> _deliver() async {
    if (name.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Recipient name required')),
      );
      return;
    }
    setState(() => busy = true);
    try {
      await _gps();
      photo ??= await ImagePicker().pickImage(
        source: ImageSource.camera,
        imageQuality: 70,
      );
      final Uint8List? signature = await sig.toPngBytes();
      if (photo == null || signature == null || signature.isEmpty) {
        throw Exception('Photo and signature required');
      }
      final photoBytes = await photo!.readAsBytes();
      final photoHash = await widget.api.uploadArtifact(photoBytes, 'photo');
      final signatureHash = await widget.api.uploadArtifact(signature, 'signature');
      await _advance(
        'DELIVERED',
        payload: {
          'proof': {
            'recipientName': name.text.trim(),
            'photoHash': photoHash,
            'signatureHash': signatureHash,
            'lat': pos!.latitude,
            'lon': pos!.longitude,
            'capturedAt': DateTime.now().toUtc().toIso8601String(),
          }
        },
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(order.id)),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(order.address, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            Text('Status: ${order.status}'),
            const SizedBox(height: 18),
            if (order.status == 'ASSIGNED')
              FilledButton(
                onPressed: () => _advance('COLLECTED'),
                child: const Text('Confirm collection'),
              ),
            if (order.status == 'COLLECTED')
              FilledButton(
                onPressed: () => _advance('EN_ROUTE'),
                child: const Text('Start route'),
              ),
            if (order.status == 'EN_ROUTE')
              FilledButton(
                onPressed: () => _advance('ARRIVED'),
                child: const Text('Arrived'),
              ),
            if (order.status == 'ARRIVED') ...[
              _ProofForm(
                name: name,
                sig: sig,
                onPhoto: () async {
                  photo = await ImagePicker().pickImage(
                    source: ImageSource.camera,
                    imageQuality: 70,
                  );
                  if (mounted) setState(() {});
                },
                hasPhoto: photo != null,
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: busy ? null : _deliver,
                child: Text(busy ? 'Saving…' : 'Complete delivery'),
              ),
            ],
            if (!['DELIVERED', 'FAILED'].contains(order.status)) ...[
              const SizedBox(height: 24),
              OutlinedButton(
                onPressed: () => _advance('FAILED'),
                child: const Text('Report failed delivery'),
              ),
            ],
          ],
        ),
      );
}

class _ProofForm extends StatelessWidget {
  const _ProofForm({
    required this.name,
    required this.sig,
    required this.onPhoto,
    required this.hasPhoto,
  });

  final TextEditingController name;
  final SignatureController sig;
  final Future<void> Function() onPhoto;
  final bool hasPhoto;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: name,
            decoration: const InputDecoration(labelText: 'Recipient name'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => onPhoto(),
            icon: const Icon(Icons.camera_alt),
            label: Text(hasPhoto ? 'Photo captured' : 'Capture photo'),
          ),
          const SizedBox(height: 12),
          const Text('Recipient signature'),
          Container(
            height: 160,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Signature(controller: sig, backgroundColor: Colors.white),
          ),
          TextButton(onPressed: sig.clear, child: const Text('Clear signature')),
        ],
      );
}
