class DeliveryOrder {
  const DeliveryOrder({
    required this.id,
    required this.status,
    required this.version,
    required this.address,
    this.customer = '',
    this.driverId,
  });

  final String id;
  final String status;
  final int version;
  final String address;
  final String customer;
  final String? driverId;

  factory DeliveryOrder.fromJson(Map<String, dynamic> j) => DeliveryOrder(
        id: '${j['id']}',
        status: '${j['status']}',
        version: (j['version'] as num?)?.toInt() ?? 1,
        address: '${j['address'] ?? ''}',
        customer: '${j['customer'] ?? ''}',
        driverId: j['driverId']?.toString(),
      );

  DeliveryOrder advance(String nextStatus) => DeliveryOrder(
        id: id,
        status: nextStatus,
        version: version + 1,
        address: address,
        customer: customer,
        driverId: driverId,
      );
}

class OutboxEvent {
  const OutboxEvent({
    required this.eventId,
    required this.orderId,
    required this.expectedVersion,
    required this.type,
    required this.payload,
    required this.createdAt,
  });

  final String eventId;
  final String orderId;
  final int expectedVersion;
  final String type;
  final Map<String, dynamic> payload;
  final String createdAt;

  Map<String, dynamic> toJson() => {
        'eventId': eventId,
        'orderId': orderId,
        'expectedVersion': expectedVersion,
        'type': type,
        'at': createdAt,
        ...payload,
      };
}
