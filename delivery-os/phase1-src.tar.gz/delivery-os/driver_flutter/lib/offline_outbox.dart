import 'dart:convert';import 'package:path/path.dart' as p;import 'package:sqflite/sqflite.dart';import 'models.dart';
class OfflineOutbox {
  Database? _db;
  Future<Database> get db async=>_db??=await openDatabase(p.join(await getDatabasesPath(),'musitu_driver.db'),version:1,onCreate:(d,_) async{await d.execute('CREATE TABLE outbox(id TEXT PRIMARY KEY, order_id TEXT NOT NULL, expected_version INTEGER NOT NULL, type TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL)');await d.execute('CREATE TABLE cache(key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)');});
  Future<void> enqueue(OutboxEvent e) async{final d=await db;await d.insert('outbox',{'id':e.eventId,'order_id':e.orderId,'expected_version':e.expectedVersion,'type':e.type,'payload':jsonEncode(e.payload),'created_at':e.createdAt},conflictAlgorithm:ConflictAlgorithm.ignore);}
  Future<List<OutboxEvent>> pending() async{final d=await db;final rows=await d.query('outbox',orderBy:'created_at ASC');return rows.map((r)=>OutboxEvent(eventId:r['id'] as String,orderId:r['order_id'] as String,expectedVersion:r['expected_version'] as int,type:r['type'] as String,payload:jsonDecode(r['payload'] as String) as Map<String,dynamic>,createdAt:r['created_at'] as String)).toList();}
  Future<void> ack(Iterable<String> ids) async{final d=await db;final batch=d.batch();for(final id in ids){batch.delete('outbox',where:'id=?',whereArgs:[id]);}await batch.commit(noResult:true);}
  Future<void> cacheJson(String key,Object value) async{final d=await db;await d.insert('cache',{'key':key,'value':jsonEncode(value),'updated_at':DateTime.now().toUtc().toIso8601String()},conflictAlgorithm:ConflictAlgorithm.replace);}
  Future<dynamic> readCache(String key) async{final d=await db;final r=await d.query('cache',where:'key=?',whereArgs:[key],limit:1);return r.isEmpty?null:jsonDecode(r.first['value'] as String);}
}
