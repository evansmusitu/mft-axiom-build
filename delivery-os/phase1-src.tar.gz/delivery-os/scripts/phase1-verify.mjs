import fs from 'node:fs';
const required = [
  'driver_flutter/pubspec.yaml',
  'driver_flutter/lib/main.dart',
  'driver_flutter/lib/api.dart',
  'driver_flutter/lib/offline_outbox.dart',
  'web/command/index.html',
  'web/track/index.html',
  'core/src/server.mjs',
  'core/src/adapter.mjs',
  'core/src/optimizer.mjs',
  'core/src/routing.mjs',
  'infra/docker-compose.yml',
  'docs/PHASE1_ACCEPTANCE.md',
  'vendor/ownfleet',
];
const missing = required.filter((p) => !fs.existsSync(new URL(`../${p}`, import.meta.url)));
if (missing.length) {
  console.error('Missing Phase-1 artifacts:', missing);
  process.exit(1);
}
console.log('MUSITU_DELIVERY_OS_PHASE1_STRUCTURE_PASS');
