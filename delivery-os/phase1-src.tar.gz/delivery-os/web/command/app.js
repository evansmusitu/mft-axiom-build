let token = '';
let stream;

const api = async (path, opts = {}) => {
  if (!token) {
    const r = await fetch('/api/v1/dispatcher/login', { method: 'POST' });
    token = (await r.json()).accessToken;
  }
  return fetch(path, {
    ...opts,
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json',
      ...(opts.headers || {}),
    },
  });
};

function render(s) {
  document.querySelector('#open').textContent = s.orders.filter(
    (o) => !['DELIVERED', 'CANCELLED'].includes(o.status),
  ).length;
  document.querySelector('#risk').textContent = s.orders.filter(
    (o) => o.priority >= 3 && !['DELIVERED', 'CANCELLED'].includes(o.status),
  ).length;
  document.querySelector('#drivers').textContent = s.drivers.filter((d) => d.online).length;
  document.querySelector('#orders').innerHTML = s.orders.map((o) => `
    <div class="order">
      <strong><span>${o.id}</span><span class="tag">${o.status}</span></strong>
      <div>${o.customer || 'Customer'}</div>
      <div class="muted">${o.address || ''} · v${o.version}</div>
    </div>`).join('');
  document.querySelector('#events').innerHTML = s.events
    .slice()
    .reverse()
    .slice(0, 20)
    .map((e) => `
      <div class="event">
        <strong>${e.type}</strong>
        <span class="muted">${e.orderId} · ${e.actor} · ${new Date(e.at).toLocaleString()}</span>
      </div>`)
    .join('');
}

async function refresh() {
  const r = await api('/api/v1/dispatcher/snapshot');
  if (r.ok) render(await r.json());
}

async function connectRealtime() {
  await api('/api/v1/dispatcher/snapshot');
  if (stream) stream.close();
  stream = new EventSource(`/api/v1/dispatcher/stream?token=${encodeURIComponent(token)}`);
  stream.addEventListener('snapshot', (event) => render(JSON.parse(event.data)));
  stream.onerror = () => setTimeout(connectRealtime, 3000);
}

document.querySelector('#refresh').onclick = refresh;
refresh();
connectRealtime();
